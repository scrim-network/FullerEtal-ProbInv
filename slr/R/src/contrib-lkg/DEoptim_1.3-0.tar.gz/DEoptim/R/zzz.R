.First.lib <- function(lib, pkg){
  cat("\nDEoptim package")
  cat("\nDifferential Evolution algorithm")
  cat("\nAuthor and maintainer : David Ardia <david.ardia@unifr.ch>\n")
}
